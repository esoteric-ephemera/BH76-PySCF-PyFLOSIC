import yaml
from os import sys,getcwd,listdir,path,system

eH_to_eV = 27.211386245988
eV_to_kcalmol = 23.06054783061903
eH_to_kcalmol = eH_to_eV*eV_to_kcalmol

# this is the directory where the files BH76_ref_energies.yaml and BH76_chg_2s.yaml are located
rdir = '/Users/aaronkaplan/Dropbox/phd.nosync/computation/BH76/'

def BH76_analysis(dir='./'):

    refs = yaml.load(open(rdir + 'BH76_ref_energies.yaml','r'),\
        Loader=yaml.Loader)

    edict = get_en_dict_yaml(wdir=dir)

    ofl = dir + 'BH76_individual.csv'
    ostr = 'System, Energy (Hartree)\n'
    for asys in edict:
        ostr += '{:}, {:}\n'.format(asys,edict[asys])

    with open(ofl,'w+') as lfl:
        lfl.write(ostr)

    md = 0.0
    mad = 0.0
    amax = -1e20
    amin = 1e20

    ostr = 'Reaction index, Energy (kcal/mol), Ref (kcal/mol), Error (kcal/mol)\n'
    nrx = 0
    for indx in refs:

        tmp = 0.0
        td = refs[indx]['Stoich']
        for aspec in td:
            if aspec in edict:
                tmp += td[aspec]*edict[aspec]
            else:
                print('WARNING, no computed energy for system '+aspec)
        tmp *= eH_to_kcalmol
        err = tmp - refs[indx]['Ref']
        aerr = abs(err)
        md += err
        mad += aerr
        amax = max(amax,aerr)
        amin = min(amin,aerr)

        ostr += ('{:}, '*3 + '{:}\n').format(indx,tmp,refs[indx]['Ref'],err)

        nrx += 1

    ostr += '--,--,--,--\n'
    ostr += 'MD (kcal/mol), {:}, , \n'.format(md/(1.0*nrx))
    ostr += 'MAD (kcal/mol), {:}, , \n'.format(mad/(1.0*nrx))
    ostr += 'AMAX (kcal/mol), {:}, , \n'.format(amax)
    ostr += 'AMIN (kcal/mol), {:}, , '.format(amin)

    ofl = dir + 'BH76_errors.csv'
    with open(ofl,'w+') as lfl:
        lfl.write(ostr)

    return


def get_en_dict_yaml(wdir='./'):

    if path.isfile(wdir + '/non_conv_list.txt'):
        system('rm ' + wdir + '/non_conv_list.txt')

    non_conv = 0
    nc_list = []
    en_dict = {}

    for adir in listdir(wdir):

        if not path.isdir(wdir+'/'+adir) or adir[0]=='.':
            continue


        tmpf = wdir+'/'+adir + '/pyscf_run.yaml'
        if path.isfile(tmpf):
            tmpd = yaml.load(open(tmpf,'r'),Loader=yaml.Loader)
        else:
            tmpd = {'Etot': 0.0, 'Converged': False}

        en_dict[adir] = tmpd['Etot']
        if not tmpd['Converged']:
            non_conv += 1
            nc_list.append(adir)

    if non_conv > 0:
        with open(wdir + '/non_conv_list.txt','w+') as tfl:
            tfl.write('Total = {:}\n'.format(non_conv))
            for tmp in nc_list:
                tfl.write('{:}\n'.format(tmp))

    return en_dict

if __name__ == "__main__":

    BH76_analysis()
